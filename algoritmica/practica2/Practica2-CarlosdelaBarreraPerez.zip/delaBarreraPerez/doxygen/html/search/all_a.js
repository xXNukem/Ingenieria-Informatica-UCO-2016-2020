var searchData=
[
  ['leerdatos',['leerDatos',['../classCombinatoria.html#a0ea982368e8ed65166235a204900055f',1,'Combinatoria']]]
];
