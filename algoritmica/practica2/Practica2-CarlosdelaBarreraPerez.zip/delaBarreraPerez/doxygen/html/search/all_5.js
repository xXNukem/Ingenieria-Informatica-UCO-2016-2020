var searchData=
[
  ['ejecutaralgoritmo',['ejecutarAlgoritmo',['../auxiliares_8cpp.html#ab98d6a9e54540dc93f4b59e02d8f15fe',1,'ejecutarAlgoritmo(int opcion):&#160;auxiliares.cpp'],['../auxiliares_8hpp.html#ab98d6a9e54540dc93f4b59e02d8f15fe',1,'ejecutarAlgoritmo(int opcion):&#160;auxiliares.cpp']]],
  ['ejecutarhanoitexto',['ejecutarHanoiTexto',['../hanoi_8hpp.html#a39d7733ebfb3a6f0404c2113f138157d',1,'hanoi.cpp']]],
  ['elapsed',['elapsed',['../classClock.html#a21636bfd72caacaeb2aacd5bfdab3b7c',1,'Clock']]],
  ['estadistica_2ecpp',['estadistica.cpp',['../estadistica_8cpp.html',1,'']]],
  ['estadistica_2ehpp',['estadistica.hpp',['../estadistica_8hpp.html',1,'']]]
];
