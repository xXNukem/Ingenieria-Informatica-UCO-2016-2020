var searchData=
[
  ['red',['RED',['../macros_8hpp.html#a8d23feea868a983c8c2b661e1e16972f',1,'macros.hpp']]],
  ['reset',['RESET',['../macros_8hpp.html#ab702106cf3b3e96750b6845ded4e0299',1,'macros.hpp']]]
];
