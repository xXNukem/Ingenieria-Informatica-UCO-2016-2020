var searchData=
[
  ['restart',['restart',['../classClock.html#a775bf97123b58c768571868341d28b08',1,'Clock']]]
];
