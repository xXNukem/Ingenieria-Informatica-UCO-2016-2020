var searchData=
[
  ['combinatoria_2ecpp',['combinatoria.cpp',['../combinatoria_8cpp.html',1,'']]],
  ['combinatoria_2ehpp',['combinatoria.hpp',['../combinatoria_8hpp.html',1,'']]]
];
