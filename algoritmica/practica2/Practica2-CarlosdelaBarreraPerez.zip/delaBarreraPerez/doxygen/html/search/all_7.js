var searchData=
[
  ['getcoeficientedeterminacion',['getCoeficienteDeterminacion',['../estadistica_8cpp.html#abfff68201ea2f7782779b87c30e670c5',1,'getCoeficienteDeterminacion(std::vector&lt; float &gt;const &amp;t_practico, std::vector&lt; float &gt;const &amp;t_teorico):&#160;estadistica.cpp'],['../estadistica_8hpp.html#abfff68201ea2f7782779b87c30e670c5',1,'getCoeficienteDeterminacion(std::vector&lt; float &gt;const &amp;t_practico, std::vector&lt; float &gt;const &amp;t_teorico):&#160;estadistica.cpp']]],
  ['getincremento',['getIncremento',['../classCombinatoria.html#a3c7f6d656c3d927c5411c38b8d84e666',1,'Combinatoria']]],
  ['getmatrizcoeficientes',['getMatrizCoeficientes',['../classSistemaMatrices.html#a796706a38636dfceb741e64e15ba120a',1,'SistemaMatrices']]],
  ['getmatrizindependientes',['getMatrizIndependientes',['../classSistemaMatrices.html#ad5c9aa53496acdb9e430ac57abe53cbf',1,'SistemaMatrices']]],
  ['getmatrizsoluciones',['getMatrizSoluciones',['../classSistemaMatrices.html#a9c50e88c80f6652bbbb1a70ecc9e9776',1,'SistemaMatrices']]],
  ['getmedia',['getMedia',['../estadistica_8cpp.html#a685590b5f252ba8e1d91cd9e6c0c6231',1,'getMedia(std::vector&lt; float &gt; m):&#160;estadistica.cpp'],['../estadistica_8hpp.html#a685590b5f252ba8e1d91cd9e6c0c6231',1,'getMedia(std::vector&lt; float &gt; m):&#160;estadistica.cpp']]],
  ['getnmax',['getNMax',['../classCombinatoria.html#abee68427a0dabbdc6ff10c0c383fbb79',1,'Combinatoria']]],
  ['getnmin',['getNMin',['../classCombinatoria.html#a0e4078c0f95a47d6e3fc74d44d06b2e4',1,'Combinatoria']]],
  ['getrepeticiones',['getRepeticiones',['../classCombinatoria.html#a97fd12e7bc40eb82a8bb8b3754893de8',1,'Combinatoria']]],
  ['getvarianza',['getVarianza',['../estadistica_8hpp.html#ae0cba6a87f6819cb1f9e85b638319ac1',1,'estadistica.hpp']]],
  ['grabarfichero',['grabarFichero',['../auxiliares_8cpp.html#aaf99de64850579659315a595da00b821',1,'grabarFichero(std::vector&lt; double &gt; const &amp;n, std::vector&lt; float &gt; const &amp;t_practico, std::vector&lt; float &gt; const &amp;t_teorico):&#160;auxiliares.cpp'],['../auxiliares_8hpp.html#aaf99de64850579659315a595da00b821',1,'grabarFichero(std::vector&lt; double &gt; const &amp;n, std::vector&lt; float &gt; const &amp;t_practico, std::vector&lt; float &gt; const &amp;t_teorico):&#160;auxiliares.cpp']]],
  ['green',['GREEN',['../macros_8hpp.html#acfbc006ea433ad708fdee3e82996e721',1,'macros.hpp']]]
];
