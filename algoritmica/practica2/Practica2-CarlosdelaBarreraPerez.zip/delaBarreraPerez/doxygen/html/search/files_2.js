var searchData=
[
  ['estadistica_2ecpp',['estadistica.cpp',['../estadistica_8cpp.html',1,'']]],
  ['estadistica_2ehpp',['estadistica.hpp',['../estadistica_8hpp.html',1,'']]]
];
