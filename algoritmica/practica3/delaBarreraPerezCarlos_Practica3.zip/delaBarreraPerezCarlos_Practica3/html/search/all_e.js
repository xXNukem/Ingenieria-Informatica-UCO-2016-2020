var searchData=
[
  ['setnumero',['setNumero',['../classEntero.html#af58ba1d0d6537dfa7e593b106769f491',1,'Entero']]],
  ['sumarnumero',['sumarNumero',['../classEntero.html#a9ce4729dbb333c98ae382f5cff0ce3db',1,'Entero']]]
];
