var searchData=
[
  ['getnumero',['getNumero',['../classEntero.html#af9e2521fcf60630d50c42aa57db1cc8a',1,'Entero']]]
];
