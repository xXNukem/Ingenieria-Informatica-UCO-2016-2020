var searchData=
[
  ['agregarcerosdelante',['agregarCerosDelante',['../funcionesbajonivel_8cpp.html#afca662d0eb80b24bea5c888c92655042',1,'agregarCerosDelante(string &amp;c, int nCeros):&#160;funcionesbajonivel.cpp'],['../funcionesbajonivel_8hpp.html#afca662d0eb80b24bea5c888c92655042',1,'agregarCerosDelante(string &amp;c, int nCeros):&#160;funcionesbajonivel.cpp']]],
  ['agregarcerosfinal',['agregarCerosFinal',['../funcionesbajonivel_8cpp.html#a2e2011e6093a8e4807adca60371a8fbd',1,'agregarCerosFinal(string &amp;c, int nCeros):&#160;funcionesbajonivel.cpp'],['../funcionesbajonivel_8hpp.html#a2e2011e6093a8e4807adca60371a8fbd',1,'agregarCerosFinal(string &amp;c, int nCeros):&#160;funcionesbajonivel.cpp']]]
];
