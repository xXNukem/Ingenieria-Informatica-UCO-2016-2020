var searchData=
[
  ['getnumero',['getNumero',['../classEntero.html#af9e2521fcf60630d50c42aa57db1cc8a',1,'Entero']]],
  ['green',['GREEN',['../macros_8hpp.html#acfbc006ea433ad708fdee3e82996e721',1,'macros.hpp']]]
];
